<?php
// This page will be used when the user clicks on the "follow" button for a particular user
// Process the transaction and insert a record into the database, then redirect the user back
session_start();
require 'connect.php';

// get user id from query string
$follow_user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

// get current user id
$current_user_id = $_SESSION['SESS_MEMBER_ID'];
// initialize username variable
$follow_user_name = "";

// check if followed
if ($follow_user_id > 0 && $current_user_id > 0) {
    // fetch the username of the user being followed
    $sql = "SELECT screen_name FROM users WHERE user_id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $follow_user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $follow_user_name = $user['screen_name'];
    }

    // insert follow into database
    $sql = "INSERT INTO follows (from_id, to_id) VALUES (?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ii", $current_user_id, $follow_user_id);
    
    if ($stmt->execute()) {
        // success
        $_SESSION['FOLLOW_SUCCESS'] = "You are now following User: $follow_user_name";
        $status = 'Successfully_Followed_User';
    } else {
        // fail
        $_SESSION['FOLLOW_SUCCESS'] = "Error following the user.";
        $status = 'Failure_To_Follow';
    }
    // close statement
    $stmt->close();
} else {
    // invalid follow attempt
    $_SESSION['FOLLOW_SUCCESS'] = "Invalid follow request.";
    $status = 'fail';
}

// redirect to index.php with status and message
header("Location: index.php?status=$status");
exit();
?>

