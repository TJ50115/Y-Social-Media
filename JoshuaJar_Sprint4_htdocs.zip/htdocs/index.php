<?php
// This is the main page for our Y website.
// It will display all posts from those we are trolling
// as well as recommend people we should be trolling.
// You can also post from here.
include 'connect.php';
include 'User.php';
include 'Tweet.php';
session_start();
date_default_timezone_set('America/Moncton');

// a slightly complex custom function I wrote to handle date/time, i'm quite proud of this one!
function timeAgo($datetime, $full = false) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    // array for time intervals
    $timeIntervals = [];
    if ($diff->y) {
        $timeIntervals[] = $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
    }
    if ($diff->m) {
        $timeIntervals[] = $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
    }
    if ($diff->d >= 7) { // calculate by weeks
        $weeks = floor($diff->d / 7);
        $timeIntervals[] = $weeks . ' week' . ($weeks > 1 ? 's' : '');
        $diff->d = $diff->d % 7; // update days to remaining
    }
    if ($diff->d) {
        $timeIntervals[] = $diff->d . ' day' . ($diff->d > 1 ? 's' : '');
    }
    if ($diff->h) {
        $timeIntervals[] = $diff->h . ' hour' . ($diff->h > 1 ? 's' : '');
    }
    if ($diff->i) {
        $timeIntervals[] = $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
    }
    if (!$full) {
        $timeIntervals = array_slice($timeIntervals, 0, 1);
    }
    return $timeIntervals ? implode(', ', $timeIntervals) . ' ago' : 'just now';
}

// session variables
if (!isset($_SESSION['SESS_MEMBER_ID'])) {
    // redirect
    header("Location: login.php");
    exit();
}

// session id = user id
$current_user_id = $_SESSION['SESS_MEMBER_ID'];

// user obj
$currentUser = new User($con, '', '', '', '', '', $current_user_id);

// fetch user details
$userDetails = $currentUser->getUserDetails();
if ($userDetails) {
    $currentUser->setUserName($userDetails['screen_name']);
    $currentUser->setFirstName($userDetails['first_name']);
    $currentUser->setLastName($userDetails['last_name']);
    $currentUser->setEmail($userDetails['email']);
    $currentUser->getPassword($userDetails['password']);
} else {
    echo "User details not found. Please check if the user ID exists in the database.";
    exit();
}

// fetch profile picture
$profilePicPath = $currentUser->getProfilePicPath();

// check if session profile pic is set
if (isset($_SESSION['uploaded_file']) && !empty($_SESSION['uploaded_file'])) {
    $profilePicPath = 'uploads/' . htmlspecialchars($_SESSION['uploaded_file']);
} elseif (!empty($userDetails['profile_pic'])) {
    $profilePicPath = 'uploads/' . htmlspecialchars($userDetails['profile_pic']);
} else {
    $profilePicPath = 'images/profilepics/ElonSilouette.jpg'; // Default profile picture
}

echo $profilePicPath; //check output

// check follow
if (isset($_SESSION['FOLLOW_SUCCESS'])) {
    echo "<script type='text/javascript'>alert('" . addslashes($_SESSION['FOLLOW_SUCCESS']) . "');</script>";
    unset($_SESSION['FOLLOW_SUCCESS']); // clear sess variable
}

// reccommended users
$users_to_troll = $currentUser->getFollowRecommendations();
?>
<?php include 'includes/Header.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="DESC MISSING">
    <meta name="author" content="Nick Taggart, nick.taggart@nbcc.ca">
    <link rel="icon" href="favicon.ico">
    <title>Y - Why use X when you can use Y!</title>
    <link href="includes/bootstrap.min.css" rel="stylesheet">
    <link href="includes/starter-template.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script>
        $(document).ready(function () {
            $("#button").hide();
            $("#myTweet").on("input", function () {
                if ($(this).val().trim() !== "") {
                    $("#button").show();
                } else {
                    $("#button").hide();
                }
            });
            $("#tweet_form").submit(function (e) {
                e.preventDefault(); // prevent default
                $("#button").hide();
                $.ajax({
                    type: "POST",
                    url: "Tweet_proc.php",
                    data: $(this).serialize(),
                    success: function (response) {
                        // success
                        location.reload(); 
                    },
                    error: function (response) {
                        // error
                        alert("Error posting tweet.");
                    }
                });
            });

            // reply click event
            $(".reply-button").click(function (e) {
                e.preventDefault();
                var tweetId = $(this).data("tweet-id");
                $("#reply_to_tweet_id").val(tweetId);
                $("#replyModal").modal("show");
            });

            // reply submission
            $("#replyForm").submit(function (e) {
                e.preventDefault();
                $.ajax({
                    type: "POST",
                    url: "Reply_proc.php",
                    data: $(this).serialize(),
                    success: function (response) {
                        // success
                        $("#replyModal").modal("hide");
                        location.reload(); 
                    },
                });
            });
        });
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="includes/bootstrap.min.js"></script>

    <script>
    $(document).ready(function() {
      // reply click handler
      $('.reply-button').click(function(e) {
        e.preventDefault();
        var tweetId = $(this).data('tweet-id');
        $('#reply_to_tweet_id').val(tweetId);
        $('#replyModal').modal('show');
      });

      // reply submission handler
      $('#replyForm').submit(function(e) {
        e.preventDefault();
        $.ajax({
          type: 'POST',
          url: 'Tweet_proc.php',
          data: $(this).serialize(),
          success: function(response) {
            $('#replyModal').modal('hide');
            location.reload(); 
          },
          error: function(xhr, status, error) {
            // error posting tweet
            alert('Error posting tweet: ' + xhr.responseText);
          }
        });
      });
    });
    </script>
</head>
<body>
<div class="header-container">
</div>
<br><br>
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="mainprofile img-rounded">
                <div class="bold">
                    <img class="bannericons" alt="User Profile Picture" src="<?php echo $profilePicPath; ?>">
                    <a href="userpage.php?user_id=<?php echo $current_user_id; ?>">
                        <?php echo htmlspecialchars($currentUser->getFullName()); ?>
                    </a><br>
                </div>
                <table>
                    <tr><td>tweets</td><td>following</td><td>followers</td></tr>
                    <tr><td>0</td><td>0</td><td>0</td></tr>
                </table>
                <br><br><br><br><br>
            </div>
            <br><br>
            <div class="trending img-rounded">
                <div class="bold">Trending</div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="img-rounded">
                <form method="post" id="tweet_form">
                    <div class="form-group">
                        <textarea class="form-control" name="myTweet" id="myTweet" rows="1" placeholder="What's on your mind?"></textarea>
                        <input type="submit" name="button" id="button" value="Send" class="btn btn-primary btn-lg btn-block login-button">
                    </div>
                </form>
            </div>
            <div class="img-rounded">
                <div class="bold">Tweets</div>
                <?php
                // fetch and display all tweets for current user
                $tweets = $currentUser->getUserTweets();

                if (count($tweets) > 0) {
                    foreach ($tweets as $tweet) {
                        // check if a retweet
                        if (isset($tweet['original_tweet_id']) && $tweet['original_tweet_id'] != 0) {
                            // retweet
                            echo "<div class='tweet' style='border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>";
                            // retweeters pfp and name
                            echo "<div style='margin-bottom: 10px;'>";
                            if (!empty($tweet['profile_pic'])) {
                                $profilePicPath = 'uploads/' . htmlspecialchars($tweet['profile_pic']);
                            } else {
                                $profilePicPath = 'images/profilepics/ElonSilouette.jpg';
                            }
                            echo "<img src='$profilePicPath' alt='Profile Picture' class='profilepic' style='width: 30px; height: 30px; border-radius: 50%; margin-right: 10px;' />";
                            echo "<div>Retweeted by <a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($tweet['user_id']) . "'>";
                            echo htmlspecialchars($tweet['first_name'] . ' ' . $tweet['last_name']);
                            echo "</a></div>";
                            echo "</div>";
                            // orig tweet
                            if (!empty($tweet['original_profile_pic'])) {
                                $profilePicPath = 'uploads/' . htmlspecialchars($tweet['original_profile_pic']);
                            } else {
                                $profilePicPath = 'images/profilepics/ElonSilouette.jpg';
                            }
                            echo "<img src='$profilePicPath' alt='Profile Picture' class='profilepic' style='width: 50px; height: 50px; float: left; margin-right: 10px;' />";
                            echo "<div class='tweet-content' style='overflow: hidden;'>";
                            echo "<strong>";
                            echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($tweet['original_user_id']) . "'>";
                            echo htmlspecialchars($tweet['original_first_name'] . ' ' . $tweet['original_last_name']);
                            echo "</a> ";
                            echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($tweet['original_user_id']) . "'>";
                            echo "@" . htmlspecialchars($tweet['original_screen_name']);
                            echo "</a> ";
                            echo timeAgo($tweet['original_date_created']);
                            echo "</strong>";
                            echo "<p>" . htmlspecialchars($tweet['original_tweet_text']) . "</p>";

                            // tweet actions
                            echo "<div class='tweet-icons'>";
                            echo "<img src='images/like.ico' alt='Like' class='tweet-icon' />";
                            echo "<a href='#' class='reply-button' data-tweet-id='" . $tweet['tweet_id'] . "'>";
                            echo "<img src='images/reply.png' alt='Reply' class='tweet-icon' />";
                            echo "</a>";
                            echo "<a href='retweet.php?tweet_id=" . $tweet['tweet_id'] . "'>";
                            echo "<img src='images/retweet.png' alt='Retweet' class='tweet-icon' />";
                            echo "</a>";
                            echo "</div>"; // close tweet icons

                            echo "</div>"; // close tweet content
                            echo "</div>"; // close tweet

                            // fetch and display retweets
                            $replies = $currentUser->getRepliesForTweet($tweet['tweet_id']);
                            foreach ($replies as $reply) {
                                echo "<div class='tweet reply' style='margin-left: 50px; border-left: 2px solid #ccc; padding-left: 10px; font-size: 0.9em; background-color: #f9f9f9; margin-top: 10px; margin-bottom: 10px; border-radius: 5px; padding: 10px;'>";
                                // check if user has profile pic
                                if (!empty($reply['profile_pic'])) {
                                    $profilePicPath = 'uploads/' . htmlspecialchars($reply['profile_pic']);
                                } else {
                                    $profilePicPath = 'images/profilepics/ElonSilouette.jpg';
                                }
                                echo "<img src='$profilePicPath' alt='Profile Picture' class='profilepic' style='width: 40px; height: 40px; float: left; margin-right: 10px;'>";
                                echo "<div class='tweet-content' style='overflow: hidden;'>";
                                echo "<strong>";
                                echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($reply['user_id']) . "'>";
                                echo htmlspecialchars($reply['first_name'] . ' ' . $reply['last_name']);
                                echo "</a> ";
                                echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($reply['user_id']) . "'>";
                                echo "@" . htmlspecialchars($reply['screen_name']);
                                echo "</a> ";
                                echo timeAgo($reply['date_created']);
                                echo "</strong>";
                                echo "<p>" . htmlspecialchars($reply['tweet_text']) . "</p>";

                                // reply
                                echo "<div class='tweet-icons'>";
                                echo "<img src='images/like.ico' alt='Like' class='tweet-icon' />";
                                echo "<a href='#' class='reply-button' data-tweet-id='" . $reply['tweet_id'] . "'>";
                                echo "<img src='images/reply.png' alt='Reply' class='tweet-icon' />";
                                echo "</a>";
                                echo "</div>"; // close reply icons

                                echo "</div>"; // close reply content
                                echo "</div>"; // close reply
                            }
                        } elseif (isset($tweet['reply_to_tweet_id']) && $tweet['reply_to_tweet_id'] == 0) {
                            // orig tweet
                            echo "<div class='tweet' style='border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;'>";
                            if (!empty($tweet['profile_pic'])) {
                                $profilePicPath = 'uploads/' . htmlspecialchars($tweet['profile_pic']);
                            } else {
                                $profilePicPath = 'images/profilepics/ElonSilouette.jpg';
                            }
                            echo "<img src='$profilePicPath' alt='Profile Picture' class='profilepic' style='width: 50px; height: 50px; float: left; margin-right: 10px;' />";
                            echo "<div class='tweet-content' style='overflow: hidden;'>";
                            echo "<strong>";
                            echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($tweet['user_id']) . "'>";
                            echo htmlspecialchars($tweet['first_name'] . ' ' . $tweet['last_name']);
                            echo "</a> ";
                            echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($tweet['user_id']) . "'>";
                            echo "@" . htmlspecialchars($tweet['screen_name']);
                            echo "</a> ";
                            echo timeAgo($tweet['date_created']);
                            echo "</strong>";
                            echo "<p>" . htmlspecialchars($tweet['tweet_text']) . "</p>";

                            // tweet actions
                            echo "<div class='tweet-icons'>";
                            echo "<img src='images/like.ico' alt='Like' class='tweet-icon' />";
                            echo "<a href='#' class='reply-button' data-tweet-id='" . $tweet['tweet_id'] . "'>";
                            echo "<img src='images/reply.png' alt='Reply' class='tweet-icon' />";
                            echo "</a>";
                            echo "<a href='retweet.php?tweet_id=" . $tweet['tweet_id'] . "'>";
                            echo "<img src='images/retweet.png' alt='Retweet' class='tweet-icon' />";
                            echo "</a>";
                            echo "</div>"; // close tweet icons

                            echo "</div>"; // close tweet content
                            echo "</div>"; // close tweet

                            // fetch and display replies
                            $replies = $currentUser->getRepliesForTweet($tweet['tweet_id']);
                            foreach ($replies as $reply) {
                                echo "<div class='tweet reply' style='margin-left: 50px; border-left: 2px solid #ccc; padding-left: 10px; font-size: 0.9em; background-color: #f9f9f9; margin-top: 10px; margin-bottom: 10px; border-radius: 5px; padding: 10px;'>";
                                // check for pfp
                                if (!empty($reply['profile_pic'])) {
                                    $profilePicPath = 'uploads/' . htmlspecialchars($reply['profile_pic']);
                                } else {
                                    $profilePicPath = 'images/profilepics/ElonSilouette.jpg';
                                }
                                echo "<img src='$profilePicPath' alt='Profile Picture' class='profilepic' style='width: 40px; height: 40px; float: left; margin-right: 10px;'>";
                                echo "<div class='tweet-content' style='overflow: hidden;'>";
                                echo "<strong>";
                                echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($reply['user_id']) . "'>";
                                echo htmlspecialchars($reply['first_name'] . ' ' . $reply['last_name']);
                                echo "</a> ";
                                echo "<a class='username-link' href='userpage.php?user_id=" . htmlspecialchars($reply['user_id']) . "'>";
                                echo "@" . htmlspecialchars($reply['screen_name']);
                                echo "</a> ";
                                echo timeAgo($reply['date_created']);
                                echo "</strong>";
                                echo "<p>" . htmlspecialchars($reply['tweet_text']) . "</p>";

                                // reply stuff
                                echo "<div class='tweet-icons'>";
                                echo "<img src='images/like.ico' alt='Like' class='tweet-icon' />";
                                echo "<a href='#' class='reply-button' data-tweet-id='" . $reply['tweet_id'] . "'>";
                                echo "<img src='images/reply.png' alt='Reply' class='tweet-icon' />";
                                echo "</a>";
                                echo "</div>"; // close tweet icons

                                echo "</div>"; // close tweet content
                                echo "</div>"; 
                            }
                        }

                        echo "<hr>";
                    }
                    
                } else {
                    echo "<p>No tweets to display.</p>";
                }
                ?>
            </div>
        </div>

        <div class="col-md-3">
            <div class="whoToTroll img-rounded">
                <div class="bold">Who to Troll?<br></div>
                <?php if (count($users_to_troll) > 0): ?>
                    <?php foreach ($users_to_troll as $user): ?>
                        <div class="user">
                            <a href="userpage.php?user_id=<?php echo $user['user_id']; ?>" class="username-link">
                                <?php
                                // check if pfp exists
                                if (!empty($user['profile_pic'])) {
                                    $profilePicPath = 'uploads/' . htmlspecialchars($user['profile_pic']);
                                } else {
                                    $profilePicPath = 'images/profilepics/ElonSilouette.jpg';
                                }
                                echo "<img src='$profilePicPath' alt='Profile Picture' class='profilepic' style='width: 50px; height: 50px; margin-right: 5px;'>";
                                echo "<span>" . htmlspecialchars($user['first_name'] . ' ' . $user['last_name'] . ' @' . $user['screen_name']) . "</span>";
                                ?>
                            </a>
                            <div>
                                <a href="follow_proc.php?user_id=<?php echo $user['user_id']; ?>" class="btn btn-primary btn-sm">Follow</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No users to follow.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- my reply modal -->
<div class="modal fade" id="replyModal" tabindex="-1" role="dialog" aria-labelledby="replyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form id="replyForm">
        <div class="modal-header">
          <h5 class="modal-title" id="replyModalLabel">Reply to Tweet</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
        </div>
        <div class="modal-body">
          <textarea name="myTweet" class="form-control" rows="3" placeholder="Your reply..."></textarea>
          <input type="hidden" name="reply_to_tweet_id" id="reply_to_tweet_id">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Reply</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

</body>
</html>