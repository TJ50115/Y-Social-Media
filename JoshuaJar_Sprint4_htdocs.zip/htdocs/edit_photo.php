<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile Picture</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="starter-template.css"> 
    <style>
        /* just a bit of inline styling */
        body {
            background-color: #333; 
            color: white; 
        }
    </style>
</head>
<body>
<!-- begin header -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"><img alt="Y Logo" src="images/y_logo.png" class="logo"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Back</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>
<!-- end header -->
<div class="content starter-template" style="margin-top: 70px;">
    <div class="container">
        <h2 class="center-align" style="color: yellow;">Upload Profile Picture</h2> <!-- Change text color to yellow -->
        <form action="edit_photo_proc.php" method="POST" enctype="multipart/form-data" class="main-center" style="background-color: black; padding: 20px; border-radius: 10px; border: 2px solid yellow;"> <!-- Add custom background -->
            <div class="form-group">
                <label for="profile_pic" style="color: yellow;">Choose a profile picture:</label> <!-- Change label text color -->
                <input type="file" name="profile_pic" id="profile_pic" accept="image/*" class="form-control" required>
            </div>
            <button type="submit" id="button" class="btn btn-primary" style="background-color: yellow; color: black;">Upload</button> <!-- Change button style -->
        </form>
    </div>
</div>

</body>
</html>
