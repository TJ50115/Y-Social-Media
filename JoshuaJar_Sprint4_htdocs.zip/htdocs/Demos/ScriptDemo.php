<?php
//Joshua Jardine, PHP Sprint #2 Exercise
// This code prevents page caching
include "../connect.php";

	header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1			
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 	// Date in the past	
	header("Pragma: no-cache");
?> 

<?php
//my query
$strSQL = "SELECT ID, Category, Image, Price, Description, Option1Desc, Option1a, Option1b, Option1c, Option1d, Option2Desc, Option2a, Option2b, Option2c, Option2d 
           FROM Products 
           WHERE Category IN ('Tools', 'Sportswear', 'Houseware') 
           ORDER BY ID";

// execute
$arrayProd = mysqli_query($con, $strSQL);

// check if executed
if (!$arrayProd) {
    die("Query failed: " . mysqli_error($con));
}
// Normally, we would place our database connectivity code here.				
// In the case of this 1-2-3 example, you will find it embedded in Step3 below.	
// while loop to fetch sql
while ($rowProd = mysqli_fetch_array($arrayProd)) {
    echo '
        <hr /><br />
        <img src="images/' . $rowProd["Image"] . '.gif" height=100 width=100 align=left />
        Item #' . $rowProd["ID"] . '<br />
        Price :: ' . number_format($rowProd["Price"], 2, ".", ",") . '<br />
        Category :: ' . $rowProd["Category"] . '<br />
        Description :: ' . $rowProd["Description"] . '<br />
    ';

    // check and display option 1 if exists
    if (!empty($rowProd["Option1Desc"])) {
        echo '<br clear=all /><br />' . $rowProd["Option1Desc"] . '<br /><ul>';
        if (!empty($rowProd["Option1a"])) echo '<li>' . $rowProd["Option1a"] . '</li>';
        if (!empty($rowProd["Option1b"])) echo '<li>' . $rowProd["Option1b"] . '</li>';
        if (!empty($rowProd["Option1c"])) echo '<li>' . $rowProd["Option1c"] . '</li>';
        if (!empty($rowProd["Option1d"])) echo '<li>' . $rowProd["Option1d"] . '</li>';
        echo '</ul>';
    }

    // check and display option 2 if exists
    if (!empty($rowProd["Option2Desc"])) {
        echo '<br clear=all /><br />' . $rowProd["Option2Desc"] . '<br /><ul>';
        if (!empty($rowProd["Option2a"])) echo '<li>' . $rowProd["Option2a"] . '</li>';
        if (!empty($rowProd["Option2b"])) echo '<li>' . $rowProd["Option2b"] . '</li>';
        if (!empty($rowProd["Option2c"])) echo '<li>' . $rowProd["Option2c"] . '</li>';
        if (!empty($rowProd["Option2d"])) echo '<li>' . $rowProd["Option2d"] . '</li>';
        echo '</ul>';
    }
}
?>
<html>
<head>
	<title>Simple Scripting Demo</title>
</head>
</body>
</BODY>
</HTML>