<?php
session_start();
include 'connect.php';
require 'User.php'; // user class

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// check if form submitted
if (isset($_POST["firstname"])) {
    // collect form data and sanitize
    $firstname = $con->real_escape_string($_POST['firstname']);
    $lastname = $con->real_escape_string($_POST['lastname']);
    $email = $con->real_escape_string($_POST['email']);
    $username = $con->real_escape_string($_POST['username']);
    $password = $con->real_escape_string($_POST['password']);
    $confirm = $con->real_escape_string($_POST['confirm']);
    $phone = $con->real_escape_string($_POST['phone']);
    $address = $con->real_escape_string($_POST['address']);
    $province = $con->real_escape_string($_POST['province']);
    $postalCode = $con->real_escape_string($_POST['postalCode']);
    $url = $con->real_escape_string($_POST['url']);
    $desc = $con->real_escape_string($_POST['desc']);
    $location = $con->real_escape_string($_POST['location']);

    // check if passwords match
    if ($password !== $confirm) {
        header("Location: signup.php?status=error&message=" . urlencode("Passwords do not match."));
        exit();
    }

    // password hash
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // user instance
    $user = new User($con, $username, $hashedPassword, $firstname, $lastname, $email);
    $user->setAddress($address);
    $user->setProvince($province);
    $user->setPostalCode($postalCode);
    $user->setContactNo($phone);
    $user->setUrl($url);
    $user->setDescription($desc);
    $user->setLocation($location);

    // user in db
    if ($user->createUser()) {
        // success
        header("Location: login.php?status=success&message=" . urlencode("Account created successfully."));
        exit();
    } else {
        // fail
        header("Location: signup.php?status=error&message=" . urlencode("Error creating account. Please try again."));
        exit();
    }
}
// cleanup
$con->close();
?>