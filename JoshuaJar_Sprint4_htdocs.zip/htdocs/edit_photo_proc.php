<?php
session_start();
//error_reporting(E_ALL); i was using this stuff for debugging
//ini_set('display_errors', 1);

include 'connect.php';
require 'User.php'; //my user class 

// check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // check if file uploaded
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile_pic']['tmp_name'];
        $fileName = $_FILES['profile_pic']['name'];
        $fileSize = $_FILES['profile_pic']['size'];
        $fileType = $_FILES['profile_pic']['type'];

        // only allowing certain file extensions, just for practice
        $allowedExtensions = ['jpg', 'jpeg', 'png'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (!in_array($fileExtension, $allowedExtensions)) {
            echo "Error: Only JPG, JPEG, and PNG files are allowed.";
            exit();
        }

        // uploads directory
        $uploadFileDir = './uploads/';
        // generate a unique file name to avoid conflicts
        $newFileName = uniqid() . '.' . $fileExtension;
        $dest_path = $uploadFileDir . $newFileName;

        // check if uploads folder exists
        if (!is_dir($uploadFileDir)) {
            mkdir($uploadFileDir, 0755, true);
        }

        // move file to directory
        if (move_uploaded_file($fileTmpPath, $dest_path)) {
            // get associated user
            $current_user_id = $_SESSION['SESS_MEMBER_ID'];

            // create user instance
            $user = new User($con, '', '', '', '', '', $current_user_id);
            
            // method to update pfp
            if ($user->updateProfilePicture($con, $newFileName)) {
                $_SESSION['message'] = "Profile picture updated successfully!";
                header("Location: index.php");
                exit();
            } else {
                echo "Error updating profile picture in the database.";
            }
        } else {
            echo "There was an error moving the uploaded file.";
        }
    } else {
        echo "No file uploaded. Error code: " . $_FILES['profile_pic']['error'];
    }
} else {
    echo "Invalid request.";
}
?>
