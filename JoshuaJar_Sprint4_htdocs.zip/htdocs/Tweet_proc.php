<?php
include 'connect.php';
include 'Tweet.php';
session_start();
date_default_timezone_set('America/Moncton');


if (isset($_SESSION['SESS_MEMBER_ID']) && isset($_POST['myTweet'])) {
    $user_id = $_SESSION['SESS_MEMBER_ID'];
    $tweet_text = $_POST['myTweet'];
    $reply_to_tweet_id = isset($_POST['reply_to_tweet_id']) ? intval($_POST['reply_to_tweet_id']) : 0;
    $original_tweet_id = isset($_POST['original_tweet_id']) ? intval($_POST['original_tweet_id']) : 0;

    // check if empty
    if (empty(trim($tweet_text))) {
        http_response_code(400);
        echo "Tweet content cannot be empty.";
        exit();
    }

    // sql statement, i had a hard time putting this into a class so it'll have to stay for now sadly
    $stmt = $con->prepare("
        INSERT INTO tweets (tweet_text, user_id, original_tweet_id, reply_to_tweet_id, date_created)
        VALUES (?, ?, ?, ?, NOW())
    ");
    if (!$stmt) {
        http_response_code(500);
        echo "Prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    // bind parameters
    $stmt->bind_param("siii", $tweet_text, $user_id, $original_tweet_id, $reply_to_tweet_id);

    // execute
    if (!$stmt->execute()) {
        http_response_code(500);
        echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
        exit();
    }

    echo 'Tweet posted successfully';

    $stmt->close();
    $con->close();
} else {
    http_response_code(400);
    echo 'Error.';
}
?>