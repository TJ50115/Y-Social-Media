<?php

// set user id from the session
$user_id = $_SESSION['SESS_MEMBER_ID'] ?? null; // using a null coalescing operator here

// base path for profile pictures
$base_path = '/uploads/'; // relative path for custom profile pictures
$default_path = '/images/profilepics/'; // relative path for default profile pictures

// initialize profile picture variable
$profile_pic = 'ElonSilouette.jpg'; // default profile picture

// check if the user is logged in
if ($user_id) { // check if user ID is set
    // query
    $query = "SELECT profile_pic FROM users WHERE user_id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $user_id); // bind user id
    $stmt->execute();
    $result = $stmt->get_result();
    
    // fetch pfp
    if ($row = $result->fetch_assoc()) {
        $profile_pic = $row['profile_pic'] ?: 'ElonSilouette.jpg'; // use user's pic otherwise default
        // check if the profile picture file exists in uploads
        if (!file_exists($_SERVER['DOCUMENT_ROOT'] . $base_path . $profile_pic)) {
            // if not check in default path
            if (!file_exists($_SERVER['DOCUMENT_ROOT'] . $default_path . $profile_pic)) {
                $profile_pic = 'ElonSilouette.jpg';
            } else {
                $profile_pic = $default_path . $profile_pic;
            }
        } else {
            $profile_pic = $base_path . $profile_pic;
        }
    }

    // end statement
    $stmt->close();

} else {
    // redirect
    header("Location: login.php");
    exit(); // exit
}
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse fixed-top">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li>
                <a class="navbar-brand" href="#"><img alt="Y Logo" src="images/y_logo.png" class="logo"></a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="index.php">
                    <img class="bannericons" alt="Home Icon" src="images/home.jfif">Home<span class="sr-only">(current)</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <img class="bannericons" alt="Trending Icon" src="images/lightning.png">Moments
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <img class="bannericons" alt="Notification Icon" src="images/bell.png">Notifications
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <img class="bannericons" alt="Messages Icon" src="images/messages.png">Messages
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ContactUs.php">
                    <img class="bannericons" alt="Contact Icon" src="images/questionmark.png">Contact Us
                </a>
            </li>
            <li class="nav-item dropdown right">
                <a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    <img src="<?php echo htmlspecialchars($profile_pic); ?>" alt="Profile Picture" class="profilepic">
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdown01">
                    <a class="dropdown-item" href="logout.php" id="logoutButton">Logout</a>
                    <a class="dropdown-item" href="edit_photo.php">Edit Profile Picture</a>
                </div>
            </li>
        </ul>
        <script>
            document.getElementById('logoutButton').addEventListener('click', function(event) {
                event.preventDefault();
                $.post('logout.php', function() {
                    window.location.href = 'login.php';
                });
            });
        </script>

        <form class="form-inline my-2 my-lg-0" action="Search.php">
            <input class="form-control mr-sm-2" type="text" name="search" placeholder="search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
    </div>
</nav>
