<?php
$numbers[0] = 5;
$numbers[1] = 10;
$numbers[2] = 3;
//easier way
//$numbers = [5,8,3]; //all on one line
//associative array
$numbers = [9 => 5, 88 => 8, 34 => 3];
$cities = ["Fredericton" => 60000, "Saint John" => 70000, "Moncton" => 80000];
//2-d array
$student = array("Jimmy" => array(99,88,77), "John" => array(55,60,70), "Sarah" => array(70,80,90));
//how many elements in our array?
echo count($student) . " number of elements in our array<BR>";
print_r($student); //print out the array (ideal for debugging)

foreach($student as $s) {
    echo $s[0] . " " . $s[1] . " " . $s[2] . "<BR>";
} //end foreach
print_r(array_reverse($numbers));
echo "<BR>";
print_r(array_flip($numbers));
echo "<BR>";
array_push($numbers, 50); //add to the end ofthe array
array_pop($numbers); //remove the last element of the array 
array_unshift($numbers, 123); //add to the beginning of the array
array_shift($numbers); //remove from the beginning 
print_r($numbers);
echo "<BR>";

//open the file
$students = file("students.txt");
foreach($students as $s) {
    echo $s . "<BR>";
    list($name, $grade1, $grade2, $grade3) = explode("|",$s);
    echo $name . " " . $grade1 . " " . $grade2 . " " . $grade3 . "<BR>";
} //end foreach

//search
if (in_array(5,$numbers)) {
    echo "Found <BR>";
}
else {echo "Not Found <BR>"; }

//sort 
sort($numbers);
print_r($numbers);

$words = array("test1", "test2", "test10", "test22");
natcasesort($words); //case-insensitive natural sort
print_r($words);

//merge array
$mergedArray = array_merge($numbers, $words,);
print_r($mergedArray);
?>