<?php
//THIS NEEDS FIXING, undefined array key search -- nov 5th, 2024
echo "COMING SOON";
//3 classes of vulnerabilities
//Software(servers,programming languages, etc)
//Poorly protected data (db protected by a weak password or admin console wide open with easy URL)
//User Input - hackers can exploit vulnerabilities due to clumsy coding or poor security practices
include("connect.php");
$searchTerm = "%" . $_POST['search'] . "%";
//$sql = "select * from users where first_name like '%$searchTerm%' or last_name like '%$searchTerm%'";
$sql = "select * from users where first_name like ? or last_name like ?";
$stmt = $con -> prepare($sql);
$stmt -> bind_param("ss", $searchTerm, $searchTerm);
$stmt -> execute();
//get the results
$results = $stmt -> get_result();
while($row = $results -> fetch_assoc()) {
    echo $row['first_name'] . " " . $row['last_name'] . "<br>";
}
echo $sql . "<br>";
$stmt -> close(); //close the statement
$con -> close(); //close the connection
//print_r(hash_algos()); //list of hashing algorithms
//security by obscurity
?>