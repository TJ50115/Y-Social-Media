<?php
//login_proc.php
// 1. grab the username/password from the form using $_POST
// 2. write an sql statement
// 2.1 if no record found, return the user to login.php with an error msg
// 2.2 if record is found, store user_id in session variable and redirect user to index.php

//logout/php
//3 lines of code to kill the session and redirect the user back to login.php

//index.php
//1. write an sql statement to get a random list of 3 people to follow
/*$sql = "SELECT first_name, last_name, screen_name, profile_pic, user_id
FROM users
WHERE user_id ! = 22 AND user_id not in
(select to_id from follows where from_id == 22)
order by rand()
limit 3";*/
// 2. loop through results and display them in "Who to Troll" on index.php
// with their first name, last name, screen name, profile pic
// 3. You have to build a URL querystring to go to follow_proc.php?user_id=22

//follow_proc.php
// 1. grab the user_id from the URL querystring with $_GET
// 2. insert into follows table
// 2.1 the from_id is the currently logged in user(grab from session variable)
// 2.2 the to_id is the user_id of the person being followed 
// 3. redirect them back to index.php with header("location")

//hint for Sprint #3-encrypting passwords
//imagine this is on signup_proc.php
$password = $_POST["txtPassword"];
$password = password_hash($password, PASSWORD_DEFAULT);
echo "encrypted password $password <BR>";
echo password_hash("Hello", PASSWORD_DEFAULT);
echo password_hash("Hello", PASSWORD_DEFAULT);

//use this on login_proc.php
$myguess = "test";
echo password_verify($myguess, $password) . " does it match <BR>";
// chapter 8 - exceptions and errors
// change the config options in php
//ini_set("display_errors", 1);
error_reporting(E_ALL);
try {
    //echo $x; //throws a warning
    //trigger_error("Error");
    $student = file("students.txt");
    $fh = fopen("ASDFASFSAFSF.txt", "r");
    if(!mysqli_connect("localhost", "username", "badpassword", "noschema")); {
        throw new Exception("Error Connecting To Database");
    }
}
catch (Exception $ex) { //type-hinting
echo "Error on Line: " . $ex->getLine() . "<BR>";
echo "Error Message " . $ex->getMessage(). "<BR>"; 
error_log("Error on Line: " . $ex->getLine() . "<BR>");
error_log("Error Message " . $ex->getMessage(). "<BR>");
}
?>