<?php
//no need to store anything in session
$prodId = $_GET["prod_id"];
echo "You have chosen product id  $prodId";

// now that you have the prod id, you can insert into a DB
?>