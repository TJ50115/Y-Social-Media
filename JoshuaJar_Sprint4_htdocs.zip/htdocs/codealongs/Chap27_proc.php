<?php include("../connect.php"); ?>

<?php
//process the form and insert a new product record
if (isset($_POST["txtProdId"])) { //only run this if form was submitted
 $productId = $_POST ["txtProdId"];
 $category = $_POST["txtCategory"];
 $description = $_POST["txtDesc"];
 $price = $_POST["txtPrice"];
 echo $productId . " " . $category . " " . $description . " " . $price . "<BR> ";//for debugging
 //AddRecord($con, $productId, $category, $description, $price);
 UpdateRecord($con, $productId, $category);
}
else {
    echo "ACCESS DENIED";
}

//type-hinting will throw an exception if the type doesn't match
function AddRecord($con, int $productId, string $category, $description, $price) {
//insert statement
    $sql = "INSERT INTO `products`(`id`,`Category`,`Description`,`Image`,`Price`)
            VALUES($productId,'$category','$description','',$price)";
    echo $sql . " SQL<BR>"; //for debugging

    //run the sql
    mysqli_query($con, $sql);
    if (mysqli_affected_rows($con) == 1) {
        $msg = "Insert_Successful";
    }
    else { //some kind of problem
        $msg = "Insert_Failed";
    }
    echo $msg;
    //redirect user back to the form
    header("location: chap27.php?message=$msg");
}

function UpdateRecord($con, $productId, $category) {
    //insert statement
        $sql = "update products set Category = '$category' where id = $productId";
        echo $sql . " SQL<BR>"; //for debugging
    
        //run the sql
        mysqli_query($con, $sql);
        if (mysqli_affected_rows($con) == 1) {
            $msg = "Update_Successful";
        }
        else { //some kind of problem
            $msg = "Update_Failed";
        }
        echo $msg;
        //redirect user back to the form
        header("location: chap27.php?message=$msg");
    }