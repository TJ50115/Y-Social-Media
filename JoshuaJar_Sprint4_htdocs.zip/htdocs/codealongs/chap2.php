<!DOCTYPE html>
<?php include ("../connect.php") ?>
<head>
<title>MY FIRST PHP PAGE</title>
<script></script>
</head>
<body>
    <?php
        //all variables begin with $
        $myName = "Josh"; //string
        $myNum = 10; //int
        echo $myName . "<BR>";
        print("The Number Is " . ++$myNum . "<BR>");
        //variable names can't begin with number or special character
        $Password = "Whatever";
        printf("The Number Is %d<BR>", $myNum);
        echo "She said \"Hello\" to me<BR>";

        //if statement
        //if ($myNum === 11) { //compares type and data
        if ($myNum <=> 0) {
            //spaceship operator returns 0 if the 2 values are equal
            //return 1 if greater than and returns -1 if less than
            echo "Equal<BR>";
        } 
        else {
            echo "Not Equal<BR>";
        }
        $value = (bool)true; //explicit cast
        echo "Value = " . $value . "<BR>";
        //implicit cast --- using type-juggling
        echo "Value of X and Y is " . ("10" + "10") . "<BR>";

       $value = 0755; //octal
       $value2 = 0xabc; //hexidecimal
       echo $value;

       //arrays
        $names[0] = "Jimmy";
        $names[1] = "Joe";
        for ($i = 0; $i<count($names); $i++) {
            echo "<BR>" . $names[$i];  
            if ($names[$i] == "Jimmy") {//found
                break;
            }

        }
        //by ref variables
        $y = &$myName;
        $myName = "Jimmy";
        echo $y . "  BYREF<BR>";

        //while loop
        while ($i <10) {
            echo pow($i, 2) . "<BR>";

            $i++; //don't forget this line
            if ($i == 5) continue;
        }
        $i = 0; //reinitialize it back to 0
        //do while
        do {
            echo pow($i, 3) . "<BR>";
            $i++;
        } while($i<10);

        //select from the products table in the productsdemo schema
        $id = 9;
        $sql = "select * from products where id = $id";
        if ($result = mysqli_query($con, $sql)) {
            while ($row = mysqli_fetch_array($result)) {
                echo $row["ID"]. " " . $row["Category"] . " " . $row["Description"] . "<BR>";
            }//end while
        }//end if
        ?>
        <p>Your name is <?=$myName?></p>
    </body>
</html>