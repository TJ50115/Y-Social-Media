<?php
echo rand(1,6) . "<BR>";
echo getrandmax() . "<BR>";
//type-hinting
function MultiplyNumbers(int $x, int $y) {
    return $x * $y;
}
//& means by ref, passes the memory location
function DisplayMessage (string &$msg) {
    $msg = "Hello!"; // changing the value here changes it in the calling function, passed by ref
    echo $msg . "<BR>";
}

//iterative method 
/*function Factorial(int $n) {
    $result = 1;
    for($i=$n; $i>0; $i--) {
        $result *= $i;
    }
    return $result;
}
*/
//recursive solution
//recursive functiosn call themselves
//must work towards a base case

function Factorial(int $n) {
    return ($n == 1) ? 1 : $n * Factorial($n - 1); //one line version
    // if ($n ==1) return 1; //base case
    // else {
    //     //echo $n . "<BR>";
    //     return $n * Factorial($n -1);
    // }
}

//pass-by-value
echo MultiplyNumbers(5,10) . " product<BR>";
$msg = "Hello World";
DisplayMessage($msg);
echo $msg . "  back in the main<br>";
echo Factorial(30) . "<BR>";
?>