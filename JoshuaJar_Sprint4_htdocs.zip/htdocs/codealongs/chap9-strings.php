<?php
function p($myString) {
    echo $myString . "<BR>";
}
//GREP - Global regular expression print
//PREG - Perl-compatable regular expressions
$students = array("Josh", "Jaxon", "Jimmy", "Joe");
$foundStudents = preg_grep('/j/i', $students); // i means case-insensitive
print_r($foundStudents); // print the array
p("");
$myString = "Jimmy Johnson";
p(preg_match("/J/", $myString)); // return boolean if the pattern matches
p(preg_match_all("/J/", $myString)); // return int for total number of matches
$myString = "$********.9.95";
p(preg_quote($myString));

$myString = "Hello World!";
$newString = preg_replace('/Hello/', 'Joe', $myString);
p($newString);

//split
$myString = "Hello~!~how~!~are~!~you?"; //squiggly-bang-squiggly
$myArray = preg_split("/~!~/", $myString);
print_r($myArray);
p("");

//comparison
$string1 = "Hello";
$string2 = "hello";
//returns 1 if greater than, returns 0 if equal, returns -1 if less than
p(strcmp($string1, $string2)); // case-insensitive compare

//tolower
p(strtolower("HELLO"));

//first letter upper case
p(ucfirst($string2)); // uppercase the 1st character
//htmlentities
$myString = "<script>alert('Hello')</script><b>PHP is awesome</b>";
p($myString);
p(htmlentities($myString));

//strip off HTML tags
p(strip_tags($myString));

mysqli_real_escape_string($con, $mySqlStatement);
?>