<?php 
session_start();  
require 'connect.php';  
require 'User.php';  // user class
$userId = (int)$userId;
// get input from form
$screen_name = isset($_POST['screen_name']) ? trim($_POST['screen_name']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';

// check if fields are empty
if (empty($screen_name) || empty($password)) {
    $status = 'error';
    $message = 'Both fields are required.';
    header("Location: login.php?status=$status&message=" . urlencode($message));
    exit(); 
}

$user = new User($con, "", "", "", "", "", 0); // user obj

// fetch user data
$userData = $user->readUserScreenName($screen_name);

// check if user exists
if ($userData) {
    // init new user object with data
    $user = new User(
        $con,
        $userData['screen_name'],
        $userData['password'],
        $userData['first_name'],
        $userData['last_name'],
        $userData['email'],
        (int)$userData['user_id'] // cast user_id to int
    );

    // verify password
    if ($user->verifyPassword($password)) {
        // if it matches, login and set sessions
        $_SESSION['SESS_FIRST_NAME'] = $user->getFirstName();
        $_SESSION['SESS_LAST_NAME'] = $user->getLastName();
        $_SESSION['SESS_MEMBER_ID'] = $user->getUserId();
        $_SESSION['SESS_SCREEN_NAME'] = $user->getUserName();

        // redirect to index
        header("Location: index.php");
        exit();  
    } else {
        $status = 'error';
        $message = 'Invalid password.';
        header("Location: login.php?status=$status&message=" . urlencode($message));
        exit();
    }
} else {
    $status = 'error';
    $message = 'User not found.';
    header("Location: login.php?status=$status&message=" . urlencode($message));
    exit();
}
?>
