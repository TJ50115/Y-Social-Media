<?php //my user class
class User {
    // user properties
    private int $userId;
    private string $userName;
    private string $password;
    private string $firstName;
    private string $lastName;
    private string $address = ' ';
    private string $province = ' ';
    private string $postalCode = ' ';
    private string $contactNo = ' ';
    private string $email;
    private string $dateAdded;
    private string $profImage = ' ';
    private string $location = ' ';
    private string $description = ' ';
    private string $url = ' ';
    private $con; // database connection
    

    // Constructor
    public function __construct($con, $userName, $password, $firstName, $lastName, $email, int $userId = 0) {
        $this->con = $con;
        $this->userName = $userName;
        $this->password = $password; // store hashed password
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->email = $email;
        $this->userId = $userId;
        $this->dateAdded = (new DateTime())->format('Y-m-d H:i:s'); // current date
    }
    
    public function readUserScreenName($screenName) {
        $stmt = $this->con->prepare("SELECT * FROM users WHERE LOWER(screen_name) = LOWER(?)");
        $stmt->bind_param("s", $screenName);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            return $result->fetch_assoc(); // return user data
        } else {
            error_log("No user found with screen_name: " . $screenName); // log
            return null; // return null if user not found
        }
    }

    public function updateProfilePicture($con, $newFileName) {
        $query = $con->prepare("UPDATE users SET profile_pic = ? WHERE user_id = ?");
        $query->bind_param("si", $newFileName, $this->userId);
        return $query->execute();
    }

    public function getFullName(): string {
        return $this->firstName . ' ' . $this->lastName;
    }

    public function getUserTweets() {
        $query = $this->con->prepare("
            SELECT 
                t.tweet_id,
                t.tweet_text,
                t.user_id,
                t.date_created,
                t.reply_to_tweet_id,
                t.original_tweet_id,
                u.first_name,
                u.last_name,
                u.screen_name,
                u.profile_pic,
                ot.tweet_text AS original_tweet_text,
                ot.date_created AS original_date_created,
                ou.user_id AS original_user_id,
                ou.first_name AS original_first_name,
                ou.last_name AS original_last_name,
                ou.screen_name AS original_screen_name,
                ou.profile_pic AS original_profile_pic
            FROM tweets t
            JOIN users u ON t.user_id = u.user_id
            LEFT JOIN tweets ot ON t.original_tweet_id = ot.tweet_id
            LEFT JOIN users ou ON ot.user_id = ou.user_id
            WHERE t.user_id = ? OR t.user_id IN (SELECT to_id FROM follows WHERE from_id = ?)
            ORDER BY t.date_created DESC
        ");
        $query->bind_param("ii", $this->userId, $this->userId);
        $query->execute();
        return $query->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getRepliesForTweet($tweetId) {
        $query = $this->con->prepare("
            SELECT 
                r.tweet_id,
                r.tweet_text,
                r.user_id,
                r.date_created,
                r.reply_to_tweet_id,
                u.first_name,
                u.last_name,
                u.screen_name,
                u.profile_pic
            FROM tweets r
            JOIN users u ON r.user_id = u.user_id
            WHERE r.reply_to_tweet_id = ?
            ORDER BY r.date_created ASC
        ");
        $query->bind_param("i", $tweetId);
        $query->execute();
        return $query->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getProfilePicPath() {
        // db query to get profile picture
        $query = $this->con->prepare("SELECT profile_pic FROM users WHERE user_id = ?");
        $query->bind_param("i", $this->userId);
        $query->execute();
        $result = $query->get_result()->fetch_assoc();
        $profilePic = $result['profile_pic'] ?? 'default_profile.jpg';

        $base_path = '/uploads/'; // relative path for custom profile pictures
        $default_path = '/images/profilepics/'; // relative path for default profile pictures

        // check if the profile picture file exists in uploads
        if (file_exists($_SERVER['DOCUMENT_ROOT'] . $base_path . $profilePic)) {
            return $base_path . $profilePic;
        } elseif (file_exists($_SERVER['DOCUMENT_ROOT'] . $default_path . $profilePic)) {
            return $default_path . $profilePic;
        } else {
            return 'images/ElonSilouette.jpg'; // default profile picture
        }
    }
    public function getUserProfilePic(): string {
        $query = $this->con->prepare("SELECT profile_pic FROM users WHERE user_id = ?");
        $query->bind_param("i", $this->userId);
        $query->execute();
        $result = $query->get_result()->fetch_assoc();
        return $result['profile_pic'] ?? 'ElonSilouette.jpg';
    }
    // getter for password
    public function getPassword(): string {
        return $this->password;
    }

    // verify password method
    public function verifyPassword($inputPassword): bool {
        return password_verify($inputPassword, $this->password); // verifies input with hashed password
    }

    public function getFollowRecommendations() {
        $query = $this->con->prepare("
            SELECT u.user_id, u.first_name, u.last_name, u.screen_name, u.profile_pic
            FROM users u
            WHERE u.user_id != ? AND u.user_id NOT IN (
            SELECT to_id FROM follows WHERE from_id = ?
            )
            ORDER BY RAND()
            LIMIT 3
        ");
        $query->bind_param("ii", $this->userId, $this->userId);
        $query->execute();
        return $query->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function getUserDetails() {
        $query = $this->con->prepare("SELECT * FROM users WHERE user_id = ?");
        $query->bind_param("i", $this->userId);
        $query->execute();
        return $query->get_result()->fetch_assoc();
    }
    

    // my getters and setters
    //get user id
    public function getUserId(): int { return $this->userId; }
    //get and set username
    public function getUserName(): string { return $this->userName; }
    public function setUserName($userName): void { $this->userName = $userName; }
    //get and set firstname
    public function getFirstName(): string { return $this->firstName; }
    public function setFirstName($firstName): void { $this->firstName = $firstName; }
    //get and set lastname
    public function getLastName(): string { return $this->lastName; }
    public function setLastName($lastName): void { $this->lastName = $lastName; }
    //get and set email
    public function getEmail(): string { return $this->email; }
    public function setEmail($email): void { $this->email = $email; }
    //get and set date added
    public function getDateAdded(): string { return $this->dateAdded; }
    public function setDateAdded($dateAdded): void { $this->dateAdded = $dateAdded; }
    //get and set address
    public function getAddress(): string { return $this->address; }
    public function setAddress($address): void { $this->address = $address; }
    //get and set province
    public function getProvince(): string { return $this->province; }
    public function setProvince($province): void { $this->province = $province; }
    //get and set postal code
    public function getPostalCode(): string { return $this->postalCode; }
    public function setPostalCode($postalCode): void { $this->postalCode = $postalCode; }
    //get and set contact number
    public function getContactNo(): string { return $this->contactNo; }
    public function setContactNo($contactNo): void { $this->contactNo = $contactNo; }
    //get and set profile image
    public function getProfImage(): string { return $this->profImage; }
    public function setProfImage($profImage): void { $this->profImage = $profImage; }
    //get and set location
    public function getLocation(): string { return $this->location; }
    public function setLocation($location): void { $this->location = $location; }
    //get and set description
    public function getDescription(): string { return $this->description; }
    public function setDescription($description): void { $this->description = $description; }
    //get and set url
    public function getUrl(): string { return $this->url; }
    public function setUrl($url): void { $this->url = $url; }

    // CRUD methods for user
    public function createUser() {
        $stmt = $this->con->prepare("INSERT INTO users (screen_name, password, first_name, last_name, email, contact_number, address, province, postal_code, url, description, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssssss", $this->userName, $this->password, $this->firstName, $this->lastName, $this->email, $this->contactNo, $this->address, $this->province, $this->postalCode, $this->url, $this->description, $this->location);

        if ($stmt->execute()) {
            $this->userId = $stmt->insert_id;
            return true;
        } else {
            return false;
        }
    }

    public function readUser($con, $userId) {
        $stmt = $con->prepare("SELECT * FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function updateUser($con) {
        $stmt = $con->prepare("UPDATE users SET screen_name = ?, first_name = ?, last_name = ?, email = ? WHERE user_id = ?");
        $stmt->bind_param("ssssi", $this->userName, $this->firstName, $this->lastName, $this->email, $this->userId);
        return $stmt->execute();
    }

    public function deleteUser($con, $userId) {
        $stmt = $con->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }

    // destructor
    public function __destruct() {
        // cleanup not used currently
    }
}

?>
