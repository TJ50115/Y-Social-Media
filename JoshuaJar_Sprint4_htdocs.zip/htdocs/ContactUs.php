<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Contact Us Page">
    <meta name="author" content="Your Name">
    <title>Contact Us</title>
    <link rel="icon" href="favicon.ico">
    <link href="includes/bootstrap.min.css" rel="stylesheet">
    <link href="includes/starter-template.css" rel="stylesheet">
    <style>
        .content-padding {
            padding-top: 40px; 
        }
    </style>
</head>
    <body>
    <?php 
include 'includes/Header.php';
?>
    <!-- main contact info-->
    <div class="container-fluid content-padding">
        <div class="row">
            <div class="col-md-8 contact-info">
                <h2><strong>Contact Us</strong></h2>
                <p><strong>Phone:</strong> (506) 460-6222</p>
                <p><strong>Fax:</strong> (506) 453-7944</p>
                <p><strong>Email:</strong> <a href="mailto:JJardine06@mynbcc.ca">JJardine06@mynbcc.ca</a></p>
                <p><strong>Address:</strong> 26 Duffie Drive, Fredericton, New Brunswick, E3B 0R6</p>
                <h3>Find Us</h3>
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11097.604112639578!2d-66.64438!3d45.94327!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ca42210ac3687bd%3A0x125526a7da03e7ab!2sNBCC%20Fredericton%20Campus!5e0!3m2!1sen!2sca!4v1726016967158!5m2!1sen!2sca" width="450" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
        <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
        <script src="includes/bootstrap.min.js"></script>
    </body>
</html>
