<?php
echo "this page will display a list of all recent likes of the current user's tweets<BR>";
echo "as well as a list of retweets of a current user's tweets<BR>";
echo "this will be similar to https://twitter.com/i/notifications";

?>
