<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Welcome to Y, the top alternative to X! Explore our features and join the community!">
    <meta name="author" content="Joshua Jardine - JJardine06@mynbcc.ca">
    <link rel="icon" href="favicon.ico">

    <title>Signup - Why use X when you can use Y!</title>

    <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">
	<!-- Bootstrap core JavaScript-->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
	
    <script src="includes/bootstrap.min.js"></script>
    
	<script type="text/javascript">
    // wait until the page is actually loaded
		document.addEventListener("DOMContentLoaded", function() {
        document.getElementById('registration_form').addEventListener('submit', function(event) { //call my form id
            event.preventDefault(); // prevent submission

            var email = document.getElementById('email').value;
            var phone = document.getElementById('phone').value;
            var postalCode = document.getElementById('postalCode').value;
            var password = document.getElementById('password').value;
            var confirmPassword = document.getElementById('confirm').value;

            var emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/; //email regex

            // validationss
            function validatePhoneNumber(phone) {
                var phonePattern = /^\(\d{3}\) \d{3}-\d{4}$/; //phone regex
                return phonePattern.test(phone);
            }

            function validatePostalCode(postalCode) {
                var postalCodePattern = /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/; //postal code regex
                return postalCodePattern.test(postalCode);
            }

            function validatePasswordsMatch(password, confirmPassword) {
                return password === confirmPassword;
            }

            function validateRequiredFields(fields) {
                for (var i = 0; i < fields.length; i++) {
                    if (fields[i].value.trim() === "") {
                        return false;
                    }
                }
                return true;
            }

            function validateFieldLengths(fields) {
                const maxLengths = {
                    firstname: 50,
                    lastname: 50,
                    email: 100,
                    username: 30,
                    password: 30,
                    phone: 15,
                    address: 100,
                    province: 50,
                    postalCode: 7,
                    url: 100,
                    desc: 200,
                    location: 100
                };
                
                for (var field of fields) {
                    if (field.value.length > maxLengths[field.name]) {
                        return false;
                    }
                }
                return true;
            }

            // fields array
            var requiredFields = [
                document.getElementById('firstname'),
                document.getElementById('lastname'),
                document.getElementById('email'),
                document.getElementById('username'),
                document.getElementById('password'),
                document.getElementById('confirm'),
                document.getElementById('phone'),
                document.getElementById('address'),
                document.getElementById('province'),
                document.getElementById('postalCode')
            ];

            // check validations
            if (!validatePhoneNumber(phone)) {
                alert("Invalid phone number. Please use (xxx) xxx-xxxx format.");
                return; 
            }
            
            if (!validatePostalCode(postalCode)) {
                alert("Invalid postal code. Please use XXX XXX format.");
                return; 
            }
            
            if (!validatePasswordsMatch(password, confirmPassword)) {
                alert("Passwords do not match.");
                return; 
            }
            
            if (!validateRequiredFields(requiredFields)) {
                alert("Please fill out all required fields.");
                return;
            }
            
            if (!validateFieldLengths(requiredFields)) {
                alert("Some fields exceed the maximum allowed length.");
                return;
            }

            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return; 
            }

            // if pass, submit form
            this.submit();
        });
    });
	</script>
  </head>

  <body>
    <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse fixed-top">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
			<a class="navbar-brand" href="index.html"><img src="images/y_logo.png" class="logo"></a>
      </div>
    </nav>

	<BR><BR>
    <div class="container">
		<div class="row">
			
			<div class="main-login main-center">
				<h5>Sign up once and troll as many people as you like!</h5>
					<form method="post" id="registration_form" action="signup_proc.php">
						
					<div class="form-group">
              <label for="firstname" class="cols-sm-2 control-label">First Name</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Enter your First Name" minlength="2" maxlength="50"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="lastname" class="cols-sm-2 control-label">Last Name</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Enter your Last Name" minlength="2" maxlength="50"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="email" class="cols-sm-2 control-label">Your Email</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Enter your Email" maxlength="100"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="username" class="cols-sm-2 control-label">Screen Name</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control"  name="username" id="username" placeholder="Enter your Screen Name" minlength="1" maxlength="30"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="password" class="cols-sm-2 control-label">Password</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="password" class="form-control"  name="password" id="password" placeholder="Enter your Password" minlength="4" maxlength="30"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="password" class="form-control"  name="confirm" id="confirm" placeholder="Confirm your Password" minlength="4" maxlength="30"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="phone" class="cols-sm-2 control-label">Phone Number</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control"  name="phone" id="phone" placeholder="Enter your Phone Number" minlength="10" maxlength="15"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="address" class="cols-sm-2 control-label">Address</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control" name="address" id="address" placeholder="Enter your Address" maxlength="100"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="province" class="cols-sm-2 control-label">Province</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <select name="province" id="province" class="textfield1" required>
                    <option value="">Select Province</option>
                    <option value="British Columbia">British Columbia</option>
                    <option value="Alberta">Alberta</option>
                    <option value="Saskatchewan">Saskatchewan</option>
                    <option value="Manitoba">Manitoba</option>
                    <option value="Ontario">Ontario</option>
                    <option value="Quebec">Quebec</option>
                    <option value="New Brunswick">New Brunswick</option>
                    <option value="Prince Edward Island">Prince Edward Island</option>
                    <option value="Nova Scotia">Nova Scotia</option>
                    <option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
                    <option value="Northwest Territories">Northwest Territories</option>
                    <option value="Nunavut">Nunavut</option>
                    <option value="Yukon">Yukon</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="postalCode" class="cols-sm-2 control-label">Postal Code</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control"  name="postalCode" id="postalCode" placeholder="Enter your Postal Code" minlength="6" maxlength="7" />
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="url" class="cols-sm-2 control-label">Url</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="url" class="form-control" name="url" id="url" placeholder="Enter your URL" maxlength="100"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="desc" class="cols-sm-2 control-label">Description</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control" name="desc" id="desc" placeholder="Description of your profile" maxlength="200"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="location" class="cols-sm-2 control-label">Location</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <input type="text" class="form-control" name="location" id="location" placeholder="Enter your Location" maxlength="100"/>
                </div>
              </div>
            </div>
						
			<div class="form-group ">
			<input type="submit" name="button" id="button" value="Register" class="btn btn-primary btn-lg btn-block login-button"/>			
			  </div>			
	       </form>
		</div>
	</div> <!-- end row -->
</div><!-- /.container -->
    
	</body>
</html>