<?php
// start the session
session_start();

// check if user logged in
if (isset($_SESSION['SESS_MEMBER_ID'])) {
    header("Location: index.php");
    exit();
}

// query params
function getQueryParams() {
    parse_str($_SERVER['QUERY_STRING'], $params);
    return $params;
}
$params = getQueryParams();
$status = isset($params['status']) ? $params['status'] : '';
$enteredPassword = isset($params['entered_password']) ? $params['entered_password'] : '';
$storedHash = isset($params['stored_hash']) ? $params['stored_hash'] : '';
$message = isset($params['message']) ? $params['message'] : '';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title>Login - Why use X when you can use Y!</title>
    <link href="includes/bootstrap.min.css" rel="stylesheet">
    <link href="includes/starter-template.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="includes/bootstrap.min.js"></script>
    <style>
      .alert-container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 1050;
      }
      .alert {
        margin: 0;
      }
    </style>
  </head>

  <body>
    <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse fixed-top">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <a class="navbar-brand" href="index.html"><img src="images/y_logo.png" class="logo"></a>
      </div>
    </nav>

    <?php
    // feedback message
    if ($status && $message) {
        $alertType = $status === 'success' ? 'alert-success' : 'alert-danger';
        echo '<div class="alert-container">';
        echo '<div class="alert ' . $alertType . ' alert-dismissible fade show" role="alert">';
        echo htmlspecialchars($message);
        echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close">';
        echo '<span aria-hidden="true">&times;</span>';
        echo '</button>';
        echo '</div>';
        echo '</div>';
    }

    if ($enteredPassword && $storedHash) {
      echo "<div class='alert alert-info'>";
      echo "<strong>Debug Info:</strong><br>";
      echo "Entered Password: " . htmlspecialchars($enteredPassword) . "<br>";
      echo "Stored Hash: " . htmlspecialchars($storedHash) . "<br>";
      echo "</div>";
  }
    ?>

    <br><br>
    <div class="container">
        <div class="row">
            <div class="main-center mainprofile">
                <h1>Y Login</h1>
                <p class="lead">Y - Social Media for egocentric billionaires and people like you.<br></p>
            </div>
            <div class="main-center mainprofile">
                <h1>Don't have a Y Account?</h1>
                <p class="lead"><a href="signup.php">Click Here</a> to begin trolling your friends, family, politicians and celebrities.<br></p>
            </div>
            <div class="main-center mainprofile">
                <h5>Please Login Here!</h5>
                <form method="post" action="login_proc.php">
                    <div class="form-group">
                        <label for="username" class="cols-sm-2 control-label">Screen Name</label>
                        <div class="cols-sm-10">
                            <div class="input-group">
                                <input type="text" class="form-control" required name="screen_name" id="screen_name" placeholder="Enter your Screen Name"/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password" class="cols-sm-2 control-label">Password</label>
                        <div class="cols-sm-10">
                            <div class="input-group">
                                <input type="password" class="form-control" required name="password" id="password" placeholder="Password"/>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <input type="submit" name="button" id="button" value="Login" class="btn btn-primary btn-lg btn-block login-button"/>
                    </div>
                </form>
            </div>
        </div> <!-- end row -->
    </div><!-- /.container -->
  </body>
</html>