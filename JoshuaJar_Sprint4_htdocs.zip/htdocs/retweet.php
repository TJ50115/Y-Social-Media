<?php
session_start();
include 'connect.php';
include 'Tweet.php';

// check if user logged in
if (!isset($_SESSION['SESS_MEMBER_ID'])) {
    header("Location: login.php");
    exit();
}

// session id = user id
$current_user_id = $_SESSION['SESS_MEMBER_ID'];

// check if tweet is passed
if (isset($_GET['tweet_id'])) {
    $original_tweet_id = $_GET['tweet_id'];
    $user_id = $_SESSION['SESS_MEMBER_ID']; // id of user retweeting

    // i had a hard time putting this into a class so it'll have to stay for now sadly
    $stmt = $con->prepare("INSERT INTO tweets (user_id, original_tweet_id, date_created) VALUES (?, ?, NOW())");
    $stmt->bind_param("ii", $user_id, $original_tweet_id);

    if ($stmt->execute()) {
        // redirect
        header("Location: index.php");
    } else {
        echo "Error retweeting: " . $stmt->error;
    }
} else {
    echo "Invalid retweet request.";
}
?>
