<?php // my tweet class
class Tweet {
    // tweet properties
    private ?int $tweetId = null;
    private ?int $originalTweetId;
    private string $tweetText;
    private ?int $replyToTweetId;
    private int $userId;
    private string $dateAdded;
    private ?int $followed_user_id = null;
    private $con;

    // constructor
    public function __construct($con, $tweetText, $userId, $originalTweetId = null, $replyToTweetId = null) {
        $this->con = $con;
        $this->tweetText = $tweetText;
        $this->userId = (int)$userId;
        $this->originalTweetId = $originalTweetId ? (int)$originalTweetId : null;
        $this->replyToTweetId = $replyToTweetId ? (int)$replyToTweetId : null;
        $this->dateAdded = date("Y-m-d H:i:s");
    }

    // save tweet
    public function save() {
        $query = $this->con->prepare("INSERT INTO tweets (tweet_text, user_id, original_tweet_id, reply_to_tweet_id, date_created) VALUES (?, ?, ?, ?, ?)");
        $query->bind_param('siiss', $this->tweetText, $this->userId, $this->originalTweetId, $this->replyToTweetId, $this->dateAdded);
        return $query->execute();
    }

    public function getFollowedUsers() {
        $query = "SELECT to_id FROM follows WHERE from_id = ?";
        $stmt = $this->con->prepare($query);
        $stmt->bind_param('i', $this->userId);  // bind user ID to the query
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            echo "No followed users found for this user.";
            return [];  // no users found
        }

        $followed_user_id = null;
        $stmt->bind_result($followed_user_id);

        $followed_users = [];
        while ($stmt->fetch()) {
            $followed_users[] = $followed_user_id;  // store followed users id
        }
        $stmt->close();

        return $followed_users;
    }


    // get tweets from followed users
    public function getTweetsFromFollowedUsers() {
        $followed_users = $this->getFollowedUsers();
        if (empty($followed_users)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($followed_users), '?'));
        $types = str_repeat('i', count($followed_users));
        $query = "SELECT t.tweet_text, t.date_created, u.screen_name, u.profile_pic 
                  FROM tweets t 
                  JOIN users u ON t.user_id = u.user_id 
                  WHERE t.user_id IN ($placeholders) 
                  ORDER BY t.date_created DESC";

        $stmt = $this->con->prepare($query);
        $stmt->bind_param($types, ...$followed_users);
        $stmt->execute();
        $result = $stmt->get_result();

        $tweets = [];
        while ($row = $result->fetch_assoc()) {
            $tweets[] = $row;
        }
        $stmt->close();

        return $tweets;
    }

    // getters and setters
    public function getTweetId(): int { return $this->tweetId; }
    public function getTweetText(): string { return $this->tweetText; }
    public function setTweetText($tweetText): void { $this->tweetText = $tweetText; }
    public function getUserId(): int { return $this->userId; }
    public function setUserId($userId): void { $this->userId = $userId; }
    public function getOriginalTweetId(): ?int { return $this->originalTweetId; }
    public function setOriginalTweetId($originalTweetId): void { $this->originalTweetId = $originalTweetId; }
    public function getReplyToTweetId(): ?int { return $this->replyToTweetId; }
    public function setReplyToTweetId($replyToTweetId): void { $this->replyToTweetId = $replyToTweetId; }
    public function getDateAdded(): string { return $this->dateAdded; }
    public function setDateAdded($dateAdded): void { $this->dateAdded = $dateAdded; }

    // crud methods for tweet
    public function createTweet($con) {
        $stmt = $con->prepare("INSERT INTO tweets (tweetText, userId, originalTweetId, replyToTweetId, dateAdded) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("siiis", $this->tweetText, $this->userId, $this->originalTweetId, $this->replyToTweetId, $this->dateAdded);
        return $stmt->execute();

    }

    public function readTweet($con, $tweetId) {
        $stmt = $con->prepare("SELECT * FROM tweets WHERE tweetId = ?");
        $stmt->bind_param("i", $tweetId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function updateTweet($con) {
        $stmt = $con->prepare("UPDATE tweets SET tweetText = ? WHERE tweetId = ?");
        $stmt->bind_param("si", $this->tweetText, $this->tweetId);
        return $stmt->execute();
    }

    public function deleteTweet($con, $tweetId) {
        $stmt = $con->prepare("DELETE FROM tweets WHERE tweetId = ?");
        $stmt->bind_param("i", $tweetId);
        return $stmt->execute();
    }

    // destructor
    public function __destruct() {
        //cleanup
    }
}
?>
