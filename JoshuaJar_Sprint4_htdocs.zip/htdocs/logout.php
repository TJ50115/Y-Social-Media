<?php
//start session
session_start();
// logs user out
unset($_SERVER["PHP_AUTH_USER"]);
// unset session variables
session_unset();
// kill session
session_destroy();
// redirect to login page
header("Location: login.php");
exit();
?>